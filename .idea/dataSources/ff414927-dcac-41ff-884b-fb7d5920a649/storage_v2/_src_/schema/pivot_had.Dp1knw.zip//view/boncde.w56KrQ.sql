create view boncde as
select `pivot_had`.`boncde_entete`.`sk_client` AS `sk_client`,
       `pivot_had`.`boncde_entete`.`numcde`    AS `numcde`,
       `pivot_had`.`boncde_entete`.`numcdesap` AS `numcdesap`,
       `pivot_had`.`boncde_entete`.`numpat`    AS `numpat`,
       `pivot_had`.`boncde_entete`.`datdem`    AS `datdem`,
       `pivot_had`.`boncde_entete`.`datliv`    AS `datliv`,
       `pivot_had`.`boncde_entete`.`jrsliv`    AS `jrsliv`,
       `pivot_had`.`boncde_entete`.`lieliv`    AS `lieliv`,
       `pivot_had`.`boncde_entete`.`lielivaut` AS `lielivaut`,
       `pivot_had`.`boncde_entete`.`tel`       AS `tel`,
       `pivot_had`.`boncde_entete`.`formidel`  AS `formidel`,
       `pivot_had`.`boncde_entete`.`coordidel` AS `coordidel`,
       `pivot_had`.`boncde_entete`.`telidel`   AS `telidel`,
       `pivot_had`.`boncde_entete`.`commen`    AS `commen`,
       `pivot_had`.`boncde_entete`.`statut`    AS `statut`,
       `pivot_had`.`boncde_entete`.`credat`    AS `credat`,
       `pivot_had`.`boncde_entete`.`creheu`    AS `creheu`,
       `pivot_had`.`boncde_entete`.`creuti`    AS `creuti`,
       `pivot_had`.`boncde_entete`.`moddat`    AS `moddat`,
       `pivot_had`.`boncde_entete`.`modheu`    AS `modheu`,
       `pivot_had`.`boncde_entete`.`moduti`    AS `moduti`
from `pivot_had`.`boncde_entete`;

